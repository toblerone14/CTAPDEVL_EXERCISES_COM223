package com.example.fakestagram

import androidx.fragment.app.Fragment

class SearchFragment : Fragment(R.layout.fragment_search) {}
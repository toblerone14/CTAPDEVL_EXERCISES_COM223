package com.example.fakestagram

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.activity.result.ActivityResultLauncher
import androidx.fragment.app.Fragment


class ProfileFragment : Fragment(R.layout.fragment_profile) {

    private lateinit var imagePickerLauncher: ActivityResultLauncher<Intent>

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val username = arguments?.getString("username_key")
        val textViewUsername = view.findViewById<TextView>(R.id.textView1)
        textViewUsername.text = username ?: "Guest"
    }
}
package com.example.myapplication_diaz

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.net.toUri

class ThirdActivity : AppCompatActivity() {


    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_third)

        // Set up window insets (for edge-to-edge UI)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Show a toast for the created state
        Log.d("Activity","Activity Three has been CREATED")

        val secondInput = intent.getStringExtra("secondInput")
        val secondText = findViewById<TextView>(R.id.textView)
        secondText.text = "$secondInput"

        val secondButton = findViewById<Button>(R.id.button1)

        secondButton.setOnClickListener {
            val githubProfileUrl = "https://github.com/toblerone14"

            // Create an implicit intent to view the URL
            val intent = Intent(Intent.ACTION_VIEW, githubProfileUrl.toUri())

            // Start the activity to open the GitHub profile in a browser or GitHub app
            startActivity(intent)

        }
    }

    override fun onStart() {
        super.onStart()
        Log.d("Activity", "Activity Three has STARTED")
    }

    override fun onResume() {
        super.onResume()
        Log.d("Activity", "Activity Three has RESUMED")
    }

    override fun onPause() {
        super.onPause()
        Log.d("Activity", "Activity Three has PAUSED")
    }

    override fun onStop() {
        super.onStop()
        Log.d("Activity", "Activity Three has STOPPED")
    }

    override fun onRestart() {
        super.onRestart()
        Log.d("Activity", "Activity Three has RESTARTED")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d("Activity", "Activity Three has DESTROYED")
    }


}
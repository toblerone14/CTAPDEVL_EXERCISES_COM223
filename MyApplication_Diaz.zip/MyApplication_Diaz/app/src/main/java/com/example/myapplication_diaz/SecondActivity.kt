package com.example.myapplication_diaz

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class SecondActivity : AppCompatActivity() {


    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_second)

        // Set up window insets (for edge-to-edge UI)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Show a toast for the created state
        Log.d("log","Activity Two has been CREATED")

        val firstInput = intent.getStringExtra("firstInput")
        val secondText = findViewById<TextView>(R.id.textView)
        secondText.text = "$firstInput"


        val secondButton = findViewById<Button>(R.id.button1)

        secondButton.setOnClickListener {
            val inputField = secondText.text.toString()
            val intent = Intent(this, ThirdActivity::class.java)

            intent.putExtra("secondInput", inputField)
            startActivity(intent)


        }
    }

    override fun onStart() {
        super.onStart()
        Log.d("log","Activity Two has STARTED")
    }

    override fun onResume() {
        super.onResume()
        Log.d( "log","Activity Two has RESUMED")
    }

    override fun onPause() {
        super.onPause()
        Log.d ("log","Activity Two has PAUSED")
    }

    override fun onStop() {
        super.onStop()
        Log.d("log","Activity Two has STOPPED")
    }

    override fun onRestart() {
        super.onRestart()
        Log.d("log","Activity Two has RESTARTED")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d("log","Activity Two has DESTROYED")
    }


}
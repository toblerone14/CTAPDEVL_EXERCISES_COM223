package com.example.fakestagram

object db {
    val posts = mutableListOf<Post>()

    init {
        posts.add(Post("Alice", "Enjoying the sunny day!", R.drawable.biden_46))
        posts.add(Post("Bob", "Just had coffee ☕", R.drawable.bush_43))
        posts.add(Post("Charlie", "Look at this cool cat!", R.drawable.carter_39))
    }

    fun addPost(post: Post) {
        posts.add(post)
    }

    fun getAllPosts(): List<Post> = posts
}